package com.capgemini.stringcreationusingfirstword;
import java.util.ArrayList;
import java.util.List;

public class StringCreationUsingFirstWord {
	public static void main(String[] args) {
		List<String> array = new ArrayList<String>();
		array.add("Revanth");
		array.add("Kalyan");
		array.add("RevanthKalyan");
		array.add("ChinniRam");
		System.out.println("String is :\n"+array);
		System.out.println("The first words of the Strings are-->");
	
		String stringresult = array.stream().map(Revanth -> Character.toString(Revanth.charAt(0))).reduce(" ", (a, b) -> a + b);
		System.out.println(stringresult);
	
	}
}
