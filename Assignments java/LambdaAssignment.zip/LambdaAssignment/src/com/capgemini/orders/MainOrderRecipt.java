package com.capgemini.orders;

public class MainOrderRecipt {

	public static void main(String[] args) {
		OrderStatus recipt = (Orderprice,OrdersStatus)->{
				if(Orderprice > 10000 && OrdersStatus =="Accepted" )
					return "Accepted";
				
		 		else 
					return "NULL";
				
					
		};
		System.out.println("Order Status is"+recipt.orderstatus(1000, "Accepted"));
	}
}
