package com.capgemini.orders;

public interface OrderStatus {

	String orderstatus(double Orderprice,String OrdersStatus);
}
