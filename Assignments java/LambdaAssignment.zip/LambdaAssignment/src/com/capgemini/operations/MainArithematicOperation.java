package com.capgemini.operations;

public class MainArithematicOperation {

	public static void main(String[] args) {
		Operation add = (a,b) -> a+b;
		System.out.println("The addition is --->"+add.operation(10,4));
		Operation sub = (a,b) -> a-b;
		System.out.println("The substraction is --->"+sub.operation(10,4));
		Operation multiplication = (a,b) -> a*b;
		System.out.println("The multiplication is --->"+multiplication.operation(10,4));
		Operation division = (a,b) -> a/b;
		System.out.println("The division is --->"+division.operation(10,4));
	}
}
