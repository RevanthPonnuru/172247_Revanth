package com.capgemini.operations;

@FunctionalInterface
public interface Operation {
 int operation(int a, int b);
}
