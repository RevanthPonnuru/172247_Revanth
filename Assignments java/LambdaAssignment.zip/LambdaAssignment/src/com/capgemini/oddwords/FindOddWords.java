package com.capgemini.oddwords;
import java.util.ArrayList;
import java.util.List;
public class FindOddWords {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<String> l=new ArrayList<String>();
l.add("R");
l.add("ev");
l.add("ant");
l.add("hsiva");

l.removeIf(oddwords ->(oddwords.length()%2!=0));
l.forEach(words -> System.out.println(words));
	}

}

