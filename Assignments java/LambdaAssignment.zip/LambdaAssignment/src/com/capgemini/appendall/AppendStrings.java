package com.capgemini.appendall;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
public class AppendStrings {
	public static void main(String[] args) {
		Map<String,String> map=new HashMap<String,String>();
		map.put("Revanth","Guntur");
		map.put("Pavan","Guntur");
		map.put("Venkatesh","Vizag");
		map.put("Kiran","Hyderabad");
		
		StringBuilder stringbuilder =new StringBuilder();
		Set<Map.Entry<String, String>> set=map.entrySet();
	
		
		for(Map.Entry<String,String> string:set) {
			stringbuilder=stringbuilder.append(string.getKey()+""+string.getValue());
		}
		
		System.out.println(stringbuilder);
		
		

	}
}
