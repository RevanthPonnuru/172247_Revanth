package com.capgemini.uppercaseconversion;
import java.util.ArrayList;
public class UpperCaseConversion {

	public static void main(String[] args) {
		ArrayList<String> list=new ArrayList<String>();
		list.add("Revanth");
		list.add("Venkatesh");
		list.add("Pavan");
		list.add("Kiran");
		list.add("Simmy");
		list.add("Shubhangi");
		list.replaceAll(convert->convert.toUpperCase());
		//list.replaceAll(convertto->convertto.toLowerCase());
		
		list.forEach(conversion->System.out.println(conversion));
		//list.forEach(conversionto->System.out.println(conversionto));
	}

}
